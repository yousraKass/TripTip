
// States
class PasswordVisibilityState {
  final bool isPasswordVisible;

  PasswordVisibilityState({required this.isPasswordVisible});
}