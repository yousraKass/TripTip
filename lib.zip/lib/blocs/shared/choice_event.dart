abstract class ChoiceEvent {}

class ChooseClient extends ChoiceEvent {}

class ChooseAgency extends ChoiceEvent {}