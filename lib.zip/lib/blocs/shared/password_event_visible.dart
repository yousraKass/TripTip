// Events
abstract class PasswordVisibilityEvent {}

class TogglePasswordVisibility extends PasswordVisibilityEvent {}
