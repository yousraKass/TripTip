
class FontFamily {
  static const String regular = 'Poppins-Regular';
  static const String medium = 'Poppins-Medium';
  static const String bold = 'Poppins-Bold';
}